/* eslint-disable no-unused-vars */
import { useState } from 'react'
import TaktakWithPlayer6x6 from './TaktakWithPlayer6x6'

function App() {
  return (
    <div className="w-full h-full">
      <TaktakWithPlayer6x6/>
    </div>
  )
}

export default App

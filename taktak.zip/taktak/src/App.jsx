/* eslint-disable no-unused-vars */
import { useState } from "react";
import TaktakWithBot6x6 from "./TaktakWithBot6x6";

function App() {
    return (
        <div className="w-full h-full">
            <TaktakWithBot6x6 />
        </div>
    );
}

export default App;
